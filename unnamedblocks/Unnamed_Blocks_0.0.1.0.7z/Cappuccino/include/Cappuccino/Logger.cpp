#include "Logger.h"

std::mutex CAP_EXPORT Logger::m_logMutex;
